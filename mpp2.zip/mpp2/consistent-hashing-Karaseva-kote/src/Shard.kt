import kotlinx.serialization.*

@Serializable
data class Shard(val shardName: String)
