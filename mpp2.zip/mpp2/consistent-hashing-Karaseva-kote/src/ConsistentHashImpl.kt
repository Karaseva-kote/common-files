import java.util.*

class ConsistentHashImpl<K> : ConsistentHash<K> {
    private var ring = TreeMap<Int, Shard>()
    private var vNodes = HashMap<Shard, Set<Int>>()

    private fun getMap(shard: Shard): Map<Shard, Set<HashRange>> {
        val result = mutableMapOf<Shard, MutableSet<HashRange>>()
        val list = ring.toList()
        var first = 0
        while (list[first].second == shard) {
            first++
            if (first == list.size) {
                return result
            }
        }
        var i = (first + 1) % list.size
        while (i != first) {
            while (i != first && list[i].second != shard) {
                i = (i + 1) % list.size
            }
            if (i == first) {
                break
            }
            val l = (i - 1 + list.size) % list.size
            while (list[i].second == shard) {
                i = (i + 1) % list.size
            }
            val r = (i - 1 + list.size) % list.size
            if (result.containsKey(list[i].second)) {
                result[list[i].second]!!.add(HashRange(list[l].first + 1, list[r].first))
            } else {
                result[list[i].second] = mutableSetOf(HashRange(list[l].first + 1, list[r].first))
            }
        }
        return result
    }

    override fun getShardByKey(key: K): Shard {
        val hash = key.hashCode()
        var b = ring.keys.filter { i -> i >= hash }
        if (b.isEmpty()) {
            b = ring.keys.toList()
        }
        val a = b.minOrNull()!!
        return ring[a]!!
    }

    override fun addShard(newShard: Shard, vnodeHashes: Set<Int>): Map<Shard, Set<HashRange>> {
        var flag = false
        if (ring.isEmpty()) {
            flag = true
        }
        for (i in vnodeHashes) {
            ring[i] = newShard
        }
        vNodes[newShard] = vnodeHashes
        if (flag) {
            return mutableMapOf()
        }
        return getMap(newShard)
    }

    override fun removeShard(shard: Shard): Map<Shard, Set<HashRange>> {
        val result = getMap(shard)
        for (ind in vNodes[shard]!!) {
            ring.remove(ind)
        }
        vNodes.remove(shard)
        return result
    }
}