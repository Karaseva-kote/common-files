package stack;

import kotlinx.atomicfu.AtomicRef;
import java.util.*;

public class StackImpl implements Stack {

    private static class Node {
        final AtomicRef<Node> next;
        final int x;

        Node(int x, Node next) {
            this.next = new AtomicRef<>(next);
            this.x = x;
        }
    }

    private enum Status {
        EMPTY,
        WRITING,
        WAITING,
        READING,
        DONE
    }

    private static class EliminationArray {
        final int capacity;
        List<Integer> array;
        List<AtomicRef<Status>> statusArray;

        EliminationArray(int capacity) {
            this.capacity = capacity;
            array = new ArrayList<>(Collections.nCopies(capacity, 0));
            statusArray = new ArrayList<>();
            for (int i = 0; i < capacity; i++) {
                statusArray.add(new AtomicRef<>(Status.EMPTY));
            }
        }
    }

    // head pointer
    private final AtomicRef<Node> head = new AtomicRef<>(null);
    private final EliminationArray eliminationArray = new EliminationArray(16);
    private final Random random = new Random();

    @Override
    public void push(int x) {
        int randInd = random.nextInt(eliminationArray.capacity);
        for (int i = -1; i < 2; i++) {
            int ind = (randInd + i + eliminationArray.capacity) % eliminationArray.capacity;
            if (eliminationArray.statusArray.get(ind).compareAndSet(Status.EMPTY, Status.WRITING)) {
                eliminationArray.array.set(ind, x);
                eliminationArray.statusArray.get(ind).compareAndSet(Status.WRITING, Status.WAITING);
                long timer = System.nanoTime() + 10;
                while (System.nanoTime() < timer) {
                    if (eliminationArray.statusArray.get(ind).compareAndSet(Status.DONE, Status.EMPTY)) {
                        return;
                    }
                }
                while (true) {
                    if (eliminationArray.statusArray.get(ind).compareAndSet(Status.WAITING, Status.EMPTY)) {
                        break;
                    }
                    if (eliminationArray.statusArray.get(ind).compareAndSet(Status.DONE, Status.EMPTY)) {
                        return;
                    }
                }
                break;
            }
        }
        while (true) {
            Node h = head.getValue();
            if (head.compareAndSet(h, new Node(x, h))) {
                return;
            }
        }
    }

    @Override
    public int pop() {
        int randInd = random.nextInt(eliminationArray.capacity);
        for (int i = -1; i < 2; i++) {
            int ind = (randInd + i + eliminationArray.capacity) % eliminationArray.capacity;
            if (eliminationArray.statusArray.get(ind).compareAndSet(Status.WAITING, Status.READING)) {
                int x = eliminationArray.array.get(ind);
                eliminationArray.statusArray.get(ind).compareAndSet(Status.READING, Status.DONE);
                return x;
            }
        }
        while (true) {
            Node h = head.getValue();
            if (h == null) return Integer.MIN_VALUE;
            if (head.compareAndSet(h, h.next.getValue())) {
                return h.x;
            }
        }
    }
}
