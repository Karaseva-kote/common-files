/**
 * @author : Karaseva Ekaterina
 */
class Solution : AtomicCounter {
    // объявите здесь нужные вам поля
    private val root = Node(0)
    private val last = ThreadLocal<Node>()

    override fun getAndAdd(x: Int): Int {
        // напишите здесь код
        if (last.get() == null) last.set(root)

        do {
            val newValue = last.get().value + x
            val next = Node(newValue)
            last.set(last.get().chooseNext.decide(next))
        } while (last.get() != next)

        return last.get().value - x
    }

    // вам наверняка потребуется дополнительный класс
    private data class Node(
            val value: Int,
            val chooseNext: Consensus<Node> = Consensus()
    )
}