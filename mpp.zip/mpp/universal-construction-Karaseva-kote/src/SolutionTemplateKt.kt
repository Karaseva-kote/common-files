/**
 * @author :TODO: LastName FirstName
 */
class SolutionTemplateKt : AtomicCounter {
    // объявите здесь нужные вам поля

    override fun getAndAdd(x: Int): Int {
        // напишите здесь код
        return 0
    }

    // вам наверняка потребуется дополнительный класс
    private class Node {

    }
}
