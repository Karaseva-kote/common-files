/**
 * @author :TODO: LastName FirstName
 */
public class SolutionTemplateJava implements AtomicCounter {
    // объявите здесь нужные вам поля

    public int getAndAdd(int x) {
        // напишите здесь код
        return 0;
    }

    // вам наверняка потребуется дополнительный класс
    private static class Node {

    }
}
