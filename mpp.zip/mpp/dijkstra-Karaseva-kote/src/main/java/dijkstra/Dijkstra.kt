package dijkstra

import kotlinx.atomicfu.atomic
import java.util.*
import java.util.concurrent.Phaser
import kotlin.Comparator
import kotlin.concurrent.thread

private val NODE_DISTANCE_COMPARATOR = Comparator<Node> { o1, o2 -> o1!!.distance.compareTo(o2!!.distance) }

fun shortestPathParallel(start: Node) {
    val workers = Runtime.getRuntime().availableProcessors()
    start.distance = 0
    val q = MultiQueue(workers * 4)
    q.add(start)
    q.inc()
    val onFinish = Phaser(workers + 1)
    repeat(workers) {
        thread {
            while (true) {
                val cur: Node = q.poll() ?: if (q.nodesInWork.value == 0) break else continue

                for (e in cur.outgoingEdges) {
                    while (true) {
                        val oldDist = e.to.distance
                        val newDist = cur.distance + e.weight
                        if (oldDist > newDist) {
                            if (e.to.casDistance(oldDist, newDist)) {
                                q.add(e.to)
                                q.inc()
                                break
                            }
                        } else break
                    }
                }
                q.dec()
            }
            onFinish.arrive()
        }
    }
    onFinish.arriveAndAwaitAdvance()
}

class MultiQueue(private val n: Int) {
    val nodesInWork = atomic(0)

    fun inc() {
        nodesInWork.incrementAndGet()
    }

    fun dec() {
        nodesInWork.decrementAndGet()
    }

    private val list: List<Queue<Node>>

    init {
        list = List(n) { PriorityQueue(n, NODE_DISTANCE_COMPARATOR) }
    }

    fun add(element: Node?): Boolean {
        val index = ((Random().nextInt() % n) + n) % n
        synchronized(list[index]) {
            list[index].add(element)
        }
        return true
    }

    fun poll(): Node? {
        val tries = 5
        repeat(tries) {
            val a = ((Random().nextInt() % n) + n) % n
            var b = ((Random().nextInt() % n) + n) % n
            if (a == b) {
                b = (b + 1) % n
            }
            val firstIndex = kotlin.math.min(a, b)
            val secondIndex = kotlin.math.max(a, b)
            val first: Node?
            val second: Node?
            var result: Node? = null
            synchronized(list[firstIndex]) {
                synchronized(list[secondIndex]) {
                    first = list[firstIndex].peek()
                    second = list[secondIndex].peek()
                    val firstDistance = first?.distance ?: Integer.MAX_VALUE
                    val secondDistance = second?.distance ?: Integer.MAX_VALUE
                    if (firstDistance != Int.MAX_VALUE || secondDistance != Int.MAX_VALUE) {
                        result = if (firstDistance < secondDistance) {
                            list[firstIndex].poll()
                            first
                        } else {
                            list[secondIndex].poll()
                            second
                        }
                    }
                }
            }
            if (result != null) return result!!
        }
        var result: Node? = null
        for (queue in list) {
            synchronized(queue) {
                if (queue.size != 0) {
                    result = queue.poll()
                }
            }
            if (result != null) break
        }
        return result
    }
}