import kotlinx.atomicfu.*

class DynamicArrayImpl<E> : DynamicArray<E> {
    private val core = atomic(Core<E>(INITIAL_CAPACITY))

    override fun get(index: Int): E {
        if (0 <= index && index < core.value.size.value) {
            return core.value.array[index].value!!
        }
        throw IllegalArgumentException()
    }

    override fun put(index: Int, element: E) {
        var core : Core<E>? = core.value
        if (index < core!!.size.value) {
            while (true) {
                core!!.array[index].getAndSet(element)
                core = core.next.value
                if (core == null)
                    return
            }
            return
        }
        throw IllegalArgumentException()
    }

    override fun pushBack(element: E) {
        while (true) {
            val newCore = this.core.value
            val sz = newCore.size.value
            val cap = newCore.capacity.value
            if (sz < cap) {
                if (!newCore.array[sz].compareAndSet(null, element)) {
                    newCore.size.compareAndSet(sz, sz + 1)
                    continue
                }
                newCore.size.compareAndSet(sz, sz + 1)
                return
            }
            val next = Core<E>(cap * 2)
            next.size.compareAndSet(0, sz)
            newCore.next.compareAndSet(null, next)
            for (i in 0 until cap)
                newCore.next.value!!.array[i].compareAndSet(null, newCore.array[i].value)
            this.core.compareAndSet(newCore, newCore.next.value!!)
        }
    }

    override val size: Int get() {
        return core.value.size.value
    }
}

private class Core<E>(
    input: Int,
) {
    val capacity = atomic(input)
    val size = atomic(0)
    val next : AtomicRef<Core<E>?> = atomic(null)
    val array = atomicArrayOfNulls<E>(input)
}

private const val INITIAL_CAPACITY = 1 // DO NOT CHANGE ME