import java.util.*
import kotlinx.atomicfu.atomic
import kotlinx.atomicfu.atomicArrayOfNulls

class FCPriorityQueue<E : Comparable<E>> {
    private val size = 16
    private val combineOp = atomicArrayOfNulls<Operation<E>>(size)
    private val q = PriorityQueue<E>()
    private val lock = atomic(false)

    /**
     * Retrieves the element with the highest priority
     * and returns it as the result of this function;
     * returns `null` if the queue is empty.
     */
    fun poll(): E? {
        val ind = setOp((Operation({ q.poll() }, null, false)))
        return lockOrResult(ind)
    }

    /**
     * Returns the element with the highest priority
     * or `null` if the queue is empty.
     */
    fun peek(): E? {
        val ind = setOp(Operation({ q.peek() }, null, false))
        return lockOrResult(ind)
    }

    /**
     * Adds the specified element to the queue.
     */
    fun add(element: E) {
        val ind = setOp(Operation({
            q.add(element)
            null }, null, false))
        lockOrResult(ind)
    }

    private fun setOp(operation: Operation<E>): Int {
        while (true) {
            val ind = Random().nextInt(size)
            if (combineOp[ind].compareAndSet(null, operation))
                return ind
        }
    }

    private fun lockOrResult(ind : Int) : E? {
        while (true) {
            val result = combineOp[ind].value
            if (result != null && result.done) {
                combineOp[ind].compareAndSet(result, null)
                return result!!.result
            }
            if (lock.compareAndSet(false, true)) {
                try {
                    combine()
                } finally {
                    lock.compareAndSet(true, false)
                }
            }
        }
    }

    private fun combine() {
        for (i in 0 until size) {
            val op = combineOp[i].value
            if (op != null && !op.done) {
                combineOp[i].compareAndSet(op, Operation(op.action, op.action(), true))
            }
        }
    }
}

class Operation<E>(val action: () -> E?, val result: E?, val done: Boolean)