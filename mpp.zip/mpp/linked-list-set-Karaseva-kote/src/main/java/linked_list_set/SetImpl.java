package linked_list_set;

import kotlinx.atomicfu.AtomicRef;

public class SetImpl implements Set {
    private static class Node {
        AtomicRef<Node> next;
        int x;

        Node(int x, Node next) {
            this.next = new AtomicRef<>(next);
            this.x = x;
        }
    }

    private static class Window {
        Node cur, next;
    }

    private static class Removed extends Node {
        Removed(Node next) {
            super(Integer.MAX_VALUE / 2, next);
        }
    }

    private final Node head = new Node(Integer.MIN_VALUE, new Node(Integer.MAX_VALUE, null));

    /**
     * Returns the {@link Window}, where cur.x < x <= next.x
     */
    private Window findWindow(int x) {
        parent : while (true) {
            Window w = new Window();
            w.cur = head;
            w.next = w.cur.next.getValue();
            while (w.next.x < x) {
                Node node = w.next.next.getValue();
                if (node instanceof Removed) {
                    node = node.next.getValue();
                    if (!w.cur.next.compareAndSet(w.next, node)) {
                        continue parent;
                    }
                    w.next = node;
                } else {
                    w.cur = w.next;
                    w.next = w.cur.next.getValue();
                    if (w.next instanceof Removed) {
                        w.next = w.next.next.getValue();
                    }
                }
            }
            return w;
        }
    }

    @Override
    public boolean add(int x) {
        while (true) {
            Window w = findWindow(x);
            if (w.next.x == x) {
                return false;
            }
            Node node = new Node(x, w.next);
            if (!(w.cur.next.getValue() instanceof Removed) && w.cur.next.compareAndSet(w.next, node)) {
                return true;
            }
        }
    }

    @Override
    public boolean remove(int x) {
        while (true) {
            Window w = findWindow(x);
            if (w.next.x != x) {
                return false;
            }
            Node node = w.next.next.getValue();
            if (!(node instanceof Removed) && w.next.next.compareAndSet(node, new Removed(node))) {
                w.cur.next.compareAndSet(w.next, node);
                return true;
            }
        }
    }

    @Override
    public boolean contains(int x) {
        Window w = findWindow(x);
        return w.next.x == x;
    }
}