package msqueue;

import kotlinx.atomicfu.AtomicRef;

public class MSQueue implements Queue {
    private final AtomicRef<Node> head;
    private final AtomicRef<Node> tail;

    public MSQueue() {
        Node dummy = new Node(0);
        head = new AtomicRef<>(dummy);
        tail = new AtomicRef<>(dummy);
    }

    @Override
    public void enqueue(int x) {
        Node newTail = new Node(x);
        while (true) {
            Node last = tail.getValue();
            if (last.next.compareAndSet(null, newTail)) {
                tail.compareAndSet(last, newTail);
                return;
            }
        }
    }

    @Override
    public int dequeue() {
        while (true) {
            Node first = head.getValue();
            Node last = tail.getValue();
            if (last == first) {
                if (first.next.getValue() == null) {
                    return Integer.MIN_VALUE;
                } else {
                    tail.compareAndSet(last, first.next.getValue());
                }
            } else {
                if (head.compareAndSet(first, first.next.getValue())) return first.next.getValue().x;
            }
        }
    }

    @Override
    public int peek() {
        while (true) {
            Node first = head.getValue();
            Node last = tail.getValue();
            if (last == first) {
                if (first.next.getValue() == null) {
                    return Integer.MIN_VALUE;
                } else {
                    tail.compareAndSet(last, first.next.getValue());
                }
            } else {
                if (head.compareAndSet(first, first)) return first.next.getValue().x;
            }
        }
    }

    private static class Node {
        final int x;
        AtomicRef<Node> next;

        Node(int x) {
            this.x = x;
            next = new AtomicRef<>(null);
        }
    }
}