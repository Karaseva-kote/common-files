/**
 * В теле класса решения разрешено использовать только переменные делегированные в класс RegularInt.
 * Нельзя volatile, нельзя другие типы, нельзя блокировки, нельзя лазить в глобальные переменные.
 *
 * @author : Karaseva Ekaterina
 */
class Solution : MonotonicClock {
    private var t1c1 by RegularInt(0)
    private var t1c2 by RegularInt(0)
    private var t1c3 by RegularInt(0)
    private var t2c1 by RegularInt(0)
    private var t2c2 by RegularInt(0)
    private var t2c3 by RegularInt(0)

    override fun write(time: Time) {
        t2c1 = time.d1
        t2c2 = time.d2
        t2c3 = time.d3
        t1c3 = t2c3
        t1c2 = t2c2
        t1c1 = t2c1
    }

    override fun read(): Time {
        val h1 = t1c1
        val m1 = t1c2
        val s1 = t1c3
        val s2 = t2c3
        val m2 = t2c2
        val h2 = t2c1
        val t1 = Time(h1, m1, s1)
        val t2 = Time(h2, m2, s2)
        if (t1 == t2) {
            return t1
        } else {
            var commonPrefixLength = 0
            if (t1.d1 == t2.d1) {
                commonPrefixLength = 1
                if (t1.d2 == t2.d2) {
                    commonPrefixLength = 2
                }
            }
            val a = t2.d1
            val b = if (commonPrefixLength >= 1) t2.d2 else 0
            val c = if (commonPrefixLength == 2) t2.d3 else 0
            return Time(a, b, c)
        }
    }
}