import java.util.Scanner;

public class Task1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt();
		int b = scanner.nextInt();
		int n = scanner.nextInt();
		b = b % n == 0? b / n: b / n + 1;
		if (a > b) {
			System.out.println("Yes");
		} else {
			System.out.println("No");
		}
	}
}
