import java.util.Scanner;

public class Task7 {
	private static final long MOD = 1000000007;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int k = scanner.nextInt();
		int[] p = new int[n];
		for (int i = 0; i < n; i++) {
			p[i] = scanner.nextInt();
		}
		long[][] dp = new long[n][k];
		for (int i = 0; i < n; i++) {
			dp[i][0] = 1;
		}
		for (int i = 1; i < k; i++) {
			for (int j = 0; j < n; j++) {
				dp[j][i] = 0;
				for (int h = 0; h < j; h++) {
					if (p[h] > p[j]) {
						dp[j][i] = (dp[j][i] + dp[h][i - 1]) % MOD;
					}
				}
			}
		}
		long ans = 0;
		for (int i = 0; i < n; i++) {
			ans = (ans + dp[i][k - 1]) % MOD;
		}
		System.out.println(ans);
	}
}
