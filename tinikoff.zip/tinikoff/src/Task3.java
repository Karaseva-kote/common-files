import java.util.Scanner;

public class Task3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String x = scanner.next();
		int i = x.length() - 1;
		while (i >= 0 && x.charAt(i) == '0') {
			i--;
		}
		int ans = 0;
		while (i >= 0) {
			if (x.charAt(i) == '0') {
				ans++;
			}
			i--;
		}
		System.out.println(ans);
	}
}
