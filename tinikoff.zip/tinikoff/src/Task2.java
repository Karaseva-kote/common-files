import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Task2 {

	private static void printSet(Set<String> set) {
		for(String s : set) {
			System.out.println(s);
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Set<String> result = new TreeSet<>();
		result.add("abc");
		result.add("acb");
		result.add("bac");
		result.add("bca");
		result.add("cab");
		result.add("cba");
		String ab = scanner.next();
		String ac = scanner.next();
		String bc = scanner.next();
		switch (ab) {
			case "<" : {
				result.remove("bac");
				result.remove("cba");
				result.remove("bca");
				break;
			}
			case ">" : {
				result.remove("abc");
				result.remove("cab");
				result.remove("acb");
				break;
			}
		}
		switch (ac) {
			case "<" : {
				result.remove("cab");
				result.remove("bca");
				result.remove("cba");
				break;
			}
			case ">" : {
				result.remove("acb");
				result.remove("bac");
				result.remove("abc");
				break;
			}
		}
		switch (bc) {
			case "<" : {
				result.remove("cba");
				result.remove("acb");
				result.remove("cab");
				break;
			}
			case ">" : {
				result.remove("bca");
				result.remove("abc");
				result.remove("bac");
				break;
			}
		}
		printSet(result);
	}
}
