import java.util.Scanner;

public class Task4 {
	public static void gen(int n) {
		int i = 0;
		while (i < n / 2) {
			System.out.print((char) ((i)%26 + 'a'));
			i++;
		}
		if (n % 2 == 1) {
			System.out.print((char) ((i)%26 + 'a'));
		}
		i--;
		while (i >= 0) {
			System.out.print((char) ((i)%26 + 'a'));
			i--;
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		StringBuilder prefix = new StringBuilder();
		int i = 0;
		while (i < n / 2) {
			System.out.print(prefix.reverse().toString());
			gen(n - (i * 2));
			System.out.println(prefix.reverse().toString());
			prefix.append((char) ((i + 1)%26 + 'a'));
			i++;
		}
		if (n % 2 == 1) {
			System.out.print(prefix.reverse().toString());
			System.out.print('a');
			System.out.println(prefix.reverse().toString());
		}
		prefix.deleteCharAt(prefix.length() - 1);
		i--;
		while (i >= 0) {
			System.out.print(prefix.reverse().toString());
			gen(n - (i * 2));
			System.out.println(prefix.reverse().toString());
			if (prefix.length() > 0) {
				prefix.deleteCharAt(prefix.length() - 1);
			}
			i--;
		}
	}
}
