import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task6 {

	private static class Point implements Comparable<Point> {
		private final int x;
		private final int ind;

		private Point(int x, int ind) {
			this.x = x;
			this.ind = ind;
		}

		@Override
		public int compareTo(Point o) {
			if (x != o.x) {
				return Integer.compare(x, o.x);
			}
			return Integer.compare(ind, o.ind);
		}

		@Override
		public String toString() {
			return "Point{" +
					"x=" + x +
					", ind=" + ind +
					'}';
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int h = scanner.nextInt();
		int m = scanner.nextInt();
		int k = scanner.nextInt();
		m = m / 2;
		List<Point> points = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			int h_i = scanner.nextInt();
			int m_i = scanner.nextInt();
			points.add(new Point(m_i % m, i));
			points.add(new Point(m_i % m + m, i));
		}
		points.sort(Point::compareTo);
		Point ans = new Point(n, n);
		for (int run = 0, i = n; i < n * 2; i++) {
			while (points.get(run).x <= points.get(i).x - k) {
				run++;
			}
			if (ans.x > i - run) {
				ans = new Point(i - run, points.get(i).x);
			}
		}
		System.out.println(ans.x + " " + (ans.ind - m));
		for (int i = 0; i < 2 * n; ++i) {
			if (points.get(i).x <= ans.ind - k || points.get(i).x >= ans.ind) {
				continue;
			}
			System.out.print((points.get(i).ind + 1) + " ");
		}
	}
}
