import java.util.Scanner;

public class TaskA {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		long w0 = 0;
		for(int i = 0; i < n; i++) {
			long w = scanner.nextLong();
			double ind = Math.log(w0 ^ w) / Math.log(2);
			w0 = w;
			if ((int) ind == 26) {
				System.out.print(' ');
			} else {
				System.out.print((char) (((int) ind ) + 'a'));
			}
		}
	}
}
