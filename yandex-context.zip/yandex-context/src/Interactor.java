import java.util.Scanner;

public class Interactor {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int r = scanner.nextInt();
		int inter = scanner.nextInt();
		int check = scanner.nextInt();
		switch (inter) {
			case 0: {
				if (r != 0) {
					System.out.println(3);
				} else {
					System.out.println(check);
				}
				break;
			}
			case 1: {
				System.out.println(check);
				break;
			}
			case 4: {
				if (r != 0) {
					System.out.println(3);
				} else {
					System.out.println(4);
				}
				break;
			}
			case 6: {
				System.out.println(0);
				break;
			}
			case 7: {
				System.out.println(1);
				break;
			}
			default: {
				System.out.println(inter);
				break;
			}
		}
	}
}
