import java.util.Scanner;

public class BuildingSchool {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		n = n % 2 == 0 ? n / 2 - 1 : n / 2;
		int a = 0;
		for (int i = 0; i <= n; i++) {
			a = scanner.nextInt();
		}
		System.out.println(a);
	}
}
