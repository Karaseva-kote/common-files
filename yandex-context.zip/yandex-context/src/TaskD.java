import java.util.Arrays;
import java.util.Scanner;

public class TaskD {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int[] d0 = new int[n + 1];
		int[] d1 = new int[n + 1];
		d0[0] = 0;
		d1[0] = 0;
		int cur0 = -1, cur1 = -1;
		String s = scanner.next();
		if (s.charAt(0) == '0') {
			cur0 = 1;
		} else {
			cur1 = 1;
		}
		for (int i = 0; i < n; i++) {
			if (s.charAt(i) == '0') {
				d0[i + 1] = d0[i] + 1;
				d1[i + 1] = d1[i];
			} else {
				d0[i + 1] = d0[i];
				d1[i + 1] = d1[i] + 1;
			}
		}
		System.out.print(-1 + " ");
		for (int i = 1; i < n; i++) {
			if (s.charAt(i) == '0') {
				if (cur0 == -1) {
					cur1 = -1;
					for (int j = i - 1; j >= 0; j--) {
						if (d0[i + 1] - d0[j] > d1[i + 1] - d1[j]){
							cur0 = j + 1;
							break;
						}
					}
				}
				System.out.print(cur0 + " ");
			} else {
				if (cur1 == -1) {
					cur0 = -1;
					for (int j = i - 1; j >= 0; j--) {
						if (d0[i + 1] - d0[j] < d1[i + 1] - d1[j]){
							cur1 = j + 1;
							break;
						}
					}
				}
				System.out.print(cur1 + " ");
			}
		}
	}
}
