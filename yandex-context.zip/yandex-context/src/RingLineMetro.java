import java.util.Scanner;

public class RingLineMetro {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt(), a = scanner.nextInt(), b = scanner.nextInt();
		int buff = a;
		a = Math.max(a, b);
		b = Math.min(buff, b);
		System.out.println(Math.min(a - b - 1, n - (a - b + 1)));
	}
}
