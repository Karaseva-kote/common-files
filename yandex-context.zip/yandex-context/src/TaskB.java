import java.util.Scanner;

public class TaskB {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int m = scanner.nextInt();
		char [][] result = new char[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				result[i][j] = '.';
			}
		}
		for (int i = 0; i < n; i++) {
			String s = scanner.next();
			for (int j = 0; j < m; j++) {
				if (s.charAt(j) != '.') {
					if (s.charAt(j) == '/' || s.charAt(j) == '\\') {
						result[n - i][m - j - 1] = s.charAt(j);
					} else {
						result[n - i - 1][m - j - 1] = s.charAt(j);
					}
				}
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(result[i][j]);
			}
			System.out.println();
		}
	}
}
