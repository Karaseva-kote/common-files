import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class TaskF2 {

//	private static int readInt(BufferedReader r) throws IOException {
//		return Integer.parseInt(r.readLine());
//	}

	public static void main(String[] args) throws IOException {
//		BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		List<Point> list = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			long x = scanner.nextLong(), y = scanner.nextLong();
			list.add(new Point(x, y));
		}
		long k = scanner.nextLong();
		int start = scanner.nextInt(), finish = scanner.nextInt();
		Queue<Integer> queue = new ArrayDeque<>();
		int[] dist = new int[n];
		for (int i = 0; i < n; i++) {
			dist[i] = -1;
		}
		dist[start - 1] = 0;
		queue.add(start - 1);
		while (!queue.isEmpty()) {
			int ind = queue.poll();
			Point v = list.get(ind);
			for (int i = 0; i < n; i++) {
				Point u = list.get(i);
				if (v.dict(u) <= k && dist[i] == -1) {
					dist[i] = dist[ind] + 1;
					queue.add(i);
					if (i == finish - 1) {
						System.out.println(dist[i]);
						return;
					}
				}
			}
		}
		System.out.println(-1);
	}

	private static class Point {
		private final long x;
		private final long y;

		public Point(long x, long y) {
			this.x = x;
			this.y = y;
		}

		public long dict(Point other) {
			return Math.abs(this.x - other.x) + Math.abs(this.y - other.y);
		}
	}
}
