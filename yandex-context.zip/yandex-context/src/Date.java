import java.util.Scanner;

public class Date {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt(), b = scanner.nextInt();
		if (a == b) {
			System.out.println(1);
			return;
		}
		if (a > 12 == b <= 12) {
			System.out.println(1);
			return;
		}
		System.out.println(0);
	}
}
