import java.util.Scanner;

public class TaskB2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int cnt = 0, max = 0;
		for (int i = 0; i < n; i++) {
			int a = scanner.nextInt();
			if (a == 1) {
				cnt++;
				continue;
			}
			if (cnt > max) {
				max = cnt;
			}
			cnt = 0;
		}
		if (cnt > max) {
			max = cnt;
		}
		System.out.println(max);
	}
}
