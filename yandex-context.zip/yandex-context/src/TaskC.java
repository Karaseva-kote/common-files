import java.util.*;

public class TaskC {

	private static long getLCD(long a, long b) {
		long c = a;
		a = Math.max(a, b);
		b = Math.min(c, b);
		while (a != 0 && b != 0) {
			a = a % b;
			c = a;
			a = b;
			b = c;
		}
		return a + b;
	}

	private static boolean checkPrime(long x) {
		for (int i = 2; i * i <= x; i++) {
			if (x % i == 0) {
				return false;
			}
		}
		return true;
	}

	private static long maxPrime(long x, Set<Long> prime, Set<Long> unprime) {
		long d = x;
		while (d > 1) {
			if (x % d == 0) {
				if (prime.contains(d)) {
					return d;
				}
				if (unprime.contains(d)) {
					while (x % d == 0) {
						x /= d;
					}
					d = x;
					continue;
				}
				if (checkPrime(d)) {
					prime.add(d);
					return d;
				}
				unprime.add(d);
				continue;
			}
			d--;
		}
		return 1;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int t = scanner.nextInt();
		Set<Long> prime_num = new HashSet<>();
		Set<Long> unprime_num = new HashSet<>();
		for (int i = 0; i < t; i++) {
			long a = scanner.nextLong();
			long b = scanner.nextLong();
			long lcd = getLCD(a, b);
			long r = (a * b) / (lcd * lcd);
			System.out.println("r = " + r);
			System.out.println(maxPrime(r, prime_num, unprime_num) * lcd);
		}
	}
}
