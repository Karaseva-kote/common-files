import java.util.Scanner;

public class TaskA2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String l = scanner.nextLine();
		String s = scanner.nextLine();
		boolean[] dict = new boolean[26];
		for (int i = 0; i < 26; i++) {
			dict[i] = false;
		}
		for (int i = 0; i < l.length(); i++) {
			dict[l.charAt(i) - 'a'] = true;
		}
		int cnt = 0;
		for (int i = 0; i < s.length(); i++) {
			if (dict[s.charAt(i) - 'a']) {
				cnt++;
			}
		}
		System.out.println(cnt);
	}
}
