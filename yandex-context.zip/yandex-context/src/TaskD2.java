//import java.util.Scanner;
//
//public class TaskD2 {
//
//	private static boolean[] result;
//
//	private static void gen(int ind, int bal, int cntOpen, StringBuilder sb) {
//		if (ind == result.length) {
//			for (boolean b : result) {
//				if (b) {
//					sb.append('(');
//				} else {
//					sb.append(')');
//				}
//			}
//			sb.append('\n');
//			return;
//		}
//		if (cntOpen < result.length / 2) {
//			result[ind] = true;
//			gen(ind + 1, bal + 1, cntOpen + 1, sb);
//		}
//		if (bal > 0) {
//			result[ind] = false;
//			gen(ind + 1, bal - 1, cntOpen, sb);
//		}
//	}
//
//	public static void main(String[] args) {
//		Scanner scanner = new Scanner(System.in);
//		int n = scanner.nextInt();
//		result = new boolean[2 * n];
//		StringBuilder ans = new StringBuilder();
//		gen(0, 0, 0, ans);
//		System.out.println(ans);
//	}
//}
import java.util.Scanner;

public class TaskD2 {

	private static void gen(int ind, boolean[] result, int bal, StringBuilder sb) {
		if (ind == result.length) {
			if (bal == 0) {
				for (boolean b : result) {
					if (b) {
						sb.append('(');
					} else {
						sb.append(')');
					}
				}
				sb.append('\n');
			}
			return;
		}
		if (bal < result.length / 2) {
			result[ind] = true;
			gen(ind + 1, result, bal + 1, sb);
		}
		if (bal > 0) {
			result[ind] = false;
			gen(ind + 1, result, bal - 1, sb);
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		boolean[] result = new boolean[2 * n];
		StringBuilder ans = new StringBuilder();
		gen(0, result, 0, ans);
		System.out.println(ans);
	}
}

