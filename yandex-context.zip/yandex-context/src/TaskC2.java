import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TaskC2 {
	public static void main(String[] args) throws IOException {
		BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(r.readLine());
		if (n == 0) {
			return;
		}
		int prev = Integer.parseInt(r.readLine());
		System.out.println(prev);
		for (int i = 1; i < n; i++) {
			int cur = Integer.parseInt(r.readLine());
			if (cur != prev) {
				System.out.println(cur);
			}
			prev = cur;
		}
	}
}
