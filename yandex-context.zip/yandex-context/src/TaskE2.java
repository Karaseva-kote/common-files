import java.util.Scanner;

public class TaskE2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String a = scanner.nextLine();
		String b = scanner.nextLine();
		int[] cntA = new int[26], cntB = new int[26];
		for (int i = 0; i < a.length(); i++) {
			cntA[a.charAt(i) - 'a']++;
		}
		for (int i = 0; i < b.length(); i++) {
			cntB[b.charAt(i) - 'a']++;
		}
		for (int i = 0; i < 26; i++) {
			if (cntA[i] != cntB[i]) {
				System.out.println(0);
				return;
			}
		}
		System.out.println(1);
	}
}
