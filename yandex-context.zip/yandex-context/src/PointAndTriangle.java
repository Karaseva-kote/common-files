import java.util.Scanner;

public class PointAndTriangle {

	public static double dist(int x1, int y1, int x2, int y2) {
		return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int d = scanner.nextInt();
		int x = scanner.nextInt(), y = scanner.nextInt();
		double d1 = dist(0, 0, x, y);
		double d2 = dist(d, 0, x, y);
		double d3 = dist(0, d, x, y);
		int ans = 1;
		if (d3 < d2) {
			if (d3 < d1) {
				ans = 3;
			}
		} else {
			if (d2 < d1) {
				ans = 2;
			}
		}
		if (x < 0 || y < 0) {
			System.out.println(ans);
			return;
		}
		int bcx = -d, bcy = d;
		int bpx = x - d, bpy = y;
		int s = bcx*bpy - bcy*bpx;
		if (s < 0) {
			System.out.println(ans);
			return;
		}
		System.out.println(0);
	}
}
